function globalChart() {
	let myChart = document.getElementById('myChart').getContext('2d');

	Chart.defaults.global.defaultFontFamily = 'Lato';
	Chart.defaults.global.defaultFontSize = 18;
	Chart.defaults.global.defaultFontColor = '#000';

	let myChart2 = document.getElementById('myChart').getContext('2d');

	Chart.defaults.global.defaultFontFamily = 'Lato';
	Chart.defaults.global.defaultFontSize = 18;
	Chart.defaults.global.defaultFontColor = '#000';
}
