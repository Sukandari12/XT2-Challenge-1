function lineChart() {

  let afstandChart = new Chart(myChart, {
    type: 'line',
    data: {
      labels: ['1', '2', '3', '4', '5'],
      datasets: [{
        label: 'Aantal Km',
        data: [155, 271, 443, 718, 1122],
        borderWidth: 1,
        borderColor: 'black',
        hoverBorderWidth: 4,
      }]
    },
    options: {
      title: {
        display: false,
        text: 'Snelheid',
        fontSize: 30
      },
      legend: {
        display: false,
        position: 'right',
        labels: {
        }
      },
      layout: {
        padding: {
          left: 20,
          right: 35
        }
      },
      tooltips: {

      }
    }
  });
}
